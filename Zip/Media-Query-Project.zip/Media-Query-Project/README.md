# Image-Hosting 

## To download just 1 single folder,
   * go to the desired folder, 
   * copy the url, 
   * go to [downgit](https://minhaskamal.github.io/DownGit/#/home) & 
   * follow the steps on the video 👇 ->

![Video Instruction](https://cloud.githubusercontent.com/assets/5456665/17822364/940bded8-6678-11e6-9603-b84d75bccec1.gif)


# Project Part of This Video 

https://youtu.be/HY8q4TD3KGM

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/HY8q4TD3KGM/maxresdefault.jpg
)](https://youtu.be/HY8q4TD3KGM)


## Image credits : 

   * [Portrait](https://www.pexels.com/photo/woman-wearing-brown-bucket-cap-732425/)
   * [Dribbble icon](https://www.flaticon.com/free-icon/dribbble-logo_87400)
   * [Behance icon](https://www.flaticon.com/free-icon/behance_254383)
   * [Twitter icon](https://www.flaticon.com/free-icon/twitter-sign_25347)
   * [Instagram icon](https://www.flaticon.com/free-icon/instagram_1384031)
